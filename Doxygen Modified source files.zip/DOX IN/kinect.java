/*!
 * @file kinect.java
 *
 * This file is the Kinect with the GUI which is displayed on the Pi/Laptop using
 * processing.
 *
 * @author Adam Beresford, Rupert Bennet, Mark Austin, James Kirk
 *
 * BSD license, all text here must be included in any redistribution.
 *
 */


import org.openkinect.freenect.*;
import org.openkinect.processing.*;
import processing.serial.*; //library used to access serial ports
import controlP5.*; //library to create GUI
import static javax.swing.JOptionPane.*;
import java.util.Calendar;

///Defining serial port to read and write to.
private Serial port;
/// Font to be used on the GUI
private PFont font;
///library used to create buttons and GUI in processing
private ControlP5 cp5;
/// control frame for the GUI
private kinectControls cf;
/// what is sent from the control frame to the main processing, to change on kinect
private int value;

///Kinect object
private Kinect kinect;
///Tilt variable to move kinect up and down
private float tilt;
///Disables/enables IR camera using boolean flag
private boolean nightVision = false;
///Get the current system time and assign to variable
private Calendar rightNow = Calendar.getInstance();

///Get only the hour integer from the system time
private int hour = rightNow.get(Calendar.HOUR_OF_DAY);

///Assign last hour variable to time that does not exist
private int lastHour = 25;

/**
 *Function used to create the secondary GUI control frame used
 * to contain the buttons needed to control the kinect.
 */
public void settings() {
  //Create 2d control frame GUI using OpenGL to render GUI
  size(600,500,P2D);
}

/**
 * Setup the main kinect video stream that is contained in the main GUI.
 *
 */
public void setup() {
  //Set kinect output image size
  size(600, 500);
  //Initialise kinect object to plugged in kinect
  kinect = new Kinect(this);
  //Initialise video from kinect
  kinect.initVideo();
  //Enable infra red
  kinect.enableIR(true);
  //Get the current tilt value of Kinect and initialise to tilt variable
  tilt = kinect.getTilt();
  //Create new control frame to contain the control buttons
  cf = new kinectControls(this, 400, 380, "Controls");
  //Set location of new control frame on screen
  surface.setLocation(420,10);
  //Disables drawing an outline around the created control frame
  noStroke();
  //Create font to be used on GUI buttons
  font = createFont("calibri light", 20);

}

/**
 * Draw the main GUI. Draw is in an infinte loop so that the Kinect
 * can be interacted with as long as the application is running.
 */
public void draw() {
  background(0);
  //Set video image in centre of main GUI frame
  image(kinect.getVideoImage(), 0, 0);
  //Method called to check what value has been sent from GUI control frame
  valueSent();

  //Only changes the camera if the time has changed
  if(hour != lastHour){
     System.out.println("Automatically setting Kinect lense format...");
     cameraTime();
  }
}

/**
 * CameraTime function used to define which camera the KInect default loads with when the
 * application is first opened. Also, changes the camera used automatically
 * depending on the times defined below.
 */
public void cameraTime(){
  //Use either normal camera or IR camera, depending on the time
  if((hour > 9) && (hour < 19)){
    kinect.enableIR(false);//Disable infra red
    System.out.println("Day time detected. Disabling IR...");
    message = "Day time detected. Disabling IR...";
  }else if(hour < 19){
    kinect.enableIR(true); //Enable infra red
    System.out.println("Night time detected. Enabling night vision...");
    message = "Night time detected. Enabling IR...";
  }else if(hour < 9){
    kinect.enableIR(true); //Enable infra red
    System.out.println("Night time detected. Enabling night vision...");
    message = "Night time detected. Enabling IR...";
  }
   lastHour = hour;//Set the last hour to the current hour to prevent a constant loop
}

/**
 * ValueSent function sends a value to the main GUI depending which button is pressed
 * in the secondary control frame GUI. The kinect then responds depending on the button
 * pressed.
 */
public void valueSent() {
    if (value == 1){ //If up button is pressed
      tilt+=10;
      System.out.println("Kinect tilting up...");
      value = 0;
    } else if (value == 2) {// If down button is pressed
      tilt-=10;
       System.out.println("Kinect tilting down... ");
      value = 0;
    } else if (value == 3){ //If capture button is pressed
      saveFrame();
       System.out.println("Kinect taking photo...");
       showMessageDialog(null, "Success! Image captured.",
      "Kinect Camera", ERROR_MESSAGE);
      value = 0;
    } else  if(value == 4){ //If toogle night vision button is pressed
       System.out.println("Night vision enabled/disabled...");
      value = 0;
      nightVision = !nightVision;
      kinect.enableIR(nightVision);
    }

    saveFrame("security.png"); //Save the captured image to to same directory as kinect app
    tilt = constrain(tilt, 0, 30); //Limit how far the kinect can be tilted
    kinect.setTilt(tilt); //Set the new tilt after a key press
  }

/**
 * Class that creates the secondary GUI as a Java PApplet (small JAva application).
 * The GUI design is defined in the class as well as the functionality of the buttons.
 */
class kinectControls extends PApplet {

  int w, h; //Initialise height and width of control frame
  PApplet parent; //Functionality of GUI
  ControlP5 cp5; //Design of GUI

  public kinectControls(PApplet _parent, int _w, int _h, String _name) {
    super();
    parent = _parent;
    w=_w;
    h=_h;
    PApplet.runSketch(new String[]{this.getClass().getName()}, this);
  }

  /**
   * Create secondary GUI by using pre defined the width and height.
   *
   */
  public void settings() {
    size(w,h);
  }

  /**
   * Setup GUI and define the functionality of each button. Each button sends an
   * int back to the main GUI which is then translated into different Functionality
   * via the main GUI.
   */
  public void setup() {
    surface.setLocation(10,10);
    font = createFont("calibri light", 20); //set custom font
    cp5 = new ControlP5(this);
    cp5.addButton("Up").plugTo(parent, "value").setValue(1).setPosition(70, 150).setSize (110, 80).setFont(font);
    cp5.addButton("Down").plugTo(parent, "value").setValue(2).setPosition(210, 150).setSize (110, 80).setFont(font);
    cp5.addButton("Capture").plugTo(parent, "value").setValue(3).setPosition(70,250).setSize (250, 80).setFont(font);
    cp5.addButton("Toggle Night Vision").plugTo(parent, "value").setValue(4).setPosition(70,50).setSize (250, 80).setFont(font);
  }
  /**
   * Set the background colour of the control frame.
   */
  public void draw() {
    background(40);
  }
}
