/*!
 * @file Motor.cpp
 *
 * This is the code which is uploaded to the Arduino connected to the
 * DC motor.
 *
 * @author Adam Beresford, Rupert Bennet, Mark Austin, James Kirk
 *
 * BSD license, all text here must be included in any redistribution.
 *
 */

#include <ArduinoJson.h>

/// Output motor pin for the arduino
const int motor = 3;
/// Allocate memory for the JSON object
StaticJsonBuffer<512> jsonBuffer;

/**
 * Method which is initially called on initialisation, sets up the board
 * rate and output pins for the motor on the Arduino.
 */
void setup() {

  Serial.begin(9600);
  pinMode(motor, OUTPUT);
}


/**
 * Repeatdly poll for serial data, check if the JSON object recieved has data
 * which is intended for the motor arduino by checking the ID. Then if we want to
 * interact with this Arduino, turn on the motor to roll the blind down. 
 */
void loop() {
  if (Serial.available() > 0) {
    String json = Serial.readStringUntil('\n');
    JsonObject& root = jsonBuffer.parseObject(json);
    int id = root["id"];
    int motorVal = root["motor"];
    if (id == 7){
      if (motorVal == 1){
        digitalWrite(motor, HIGH);
        delay(5000);
        digitalWrite(motor, LOW);
      }
    }
  }
}
