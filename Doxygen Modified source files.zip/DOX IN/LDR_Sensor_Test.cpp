/*!
 * @file LDR_Sensor_Test.cpp
 *
 * This is the code which is uploaded to the Arduino which uses the LDR
 * sensor to check for changes in the light levels.
 *
 * @author Adam Beresford, Rupert Bennet, Mark Austin, James Kirk
 *
 * BSD license, all text here must be included in any redistribution.
 *
 */




/// the cell and 10K pulldown are connected to a0
int photocellPin = 0;
/// the analog reading from the sensor divider
int photocellReading;
/// connect Red LED to pin 10 (PWM pin)
int LEDpin = 10;
/// Store the value to set the LED brightness depending on light reading
int LEDbrightness;

/// Inital setup of arduino, set up the serial connection with the board rate
void setup(void) {
  // We'll send debugging information via the Serial monitor
  Serial.begin(9600);
}


/**
 * Constantly check for a reading from the LDR sensor, adjust the LEDbrightness
 * depending the value on the LDR sensor, this is here for debugging so we can check
 * that it is getting changing LDR readings without putting out  to the serial.
 */
void loop(void) {
  photocellReading = analogRead(photocellPin);

  Serial.print("Analog reading = ");
  Serial.println(photocellReading);     // the raw analog reading

  // LED gets brighter the darker it is at the sensor
  // that means we have to -invert- the reading from 0-1023 back to 1023-0
  photocellReading = 1023 - photocellReading;
  //now we have to map 0-1023 to 0-255 since thats the range analogWrite uses
  LEDbrightness = map(photocellReading, 0, 1023, 0, 255);
  analogWrite(LEDpin, LEDbrightness);

  delay(100);
}
