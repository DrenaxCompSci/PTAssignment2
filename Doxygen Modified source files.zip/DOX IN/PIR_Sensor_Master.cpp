/*!
 * @file PIR_Sensor_Master.cpp
 *
 * This is the code which is uploaded to the Arduino connected to the
 * motion sensor.
 *
 * @author Adam Beresford, Rupert Bennet, Mark Austin, James Kirk
 *
 * BSD license, all text here must be included in any redistribution.
 *
 */


/// The time taken to adjust to surroudnings
int calibrationTime = 30;
/// how long it takes to change from low to high
long unsigned int lowIn;
/// time
long unsigned int pause = 5000;
/// stay on low
boolean lockLow = true;
/// use low time
boolean takeLowTime;

/// pin on the arduino which the PIR sensor is connected to for output
int pirPin = 5;
/// the pin on the arduino the LED is connected to
int ledPin = 13;


/// ID and value which are to be used for the JSON object
struct values{
  int ID;
  char Val;
};


/// Initial setup when the system is booted, set up the serial, board rate, and pins
void setup(){
  Serial.begin(9600);
  pinMode(pirPin, INPUT);
  pinMode(ledPin, OUTPUT);
  digitalWrite(pirPin, LOW);
  for(int i = 0; i < calibrationTime; i++){
    delay(1000);
  }
  delay(50);
}


/**
 * repeadly poll for changing PIR value. If motion detected, turn LED on for debugging
 * purposes. 
 */
void loop(){
  if(digitalRead(pirPin) == HIGH){
    values variable = {1,'H'};
    Serial.write((const uint8_t *)&variable, sizeof(variable));
    digitalWrite(ledPin, HIGH);
    delay(10000);
    values variable2 = {1,'L'};
    Serial.write((const uint8_t *)&variable2, sizeof(variable2));
    digitalWrite(ledPin, LOW);
  }
}

// void loop(){
//   delay(10000);
//   values variable = {1,'H'};
//   Serial.write((const uint8_t *)&variable, sizeof(variable));
//   digitalWrite(ledPin, HIGH);
//   delay(10000);
//   values variable2 = {1,'L'};
//   Serial.write((const uint8_t *)&variable2, sizeof(variable2));
//   digitalWrite(ledPin, LOW);
// }


// void loop(){
//     if(digitalRead(pirPin) == HIGH){
//       values variable = {1,'H'};
//       Serial.write((const uint8_t *)&variable, sizeof(variable));
//       digitalWrite(ledPin, HIGH);
//       delay(10000);
//       // if(lockLow){
//       //   //makes sure we wait for a transition to LOW before any further output is made:
//       //   lockLow = false;
//       //   delay(50);
//       //   }
//       //   takeLowTime = true;
//       }

//     else if(digitalRead(pirPin) == LOW){
//     values variable2 = {1,'L'};
//     Serial.write((const uint8_t *)&variable2, sizeof(variable2));
//     digitalWrite(ledPin, LOW);
//     delay(10000);
//       // if(takeLowTime){
//       //   lowIn = millis();          //save the time of the transition from high to LOW
//       //   takeLowTime = false;       //make sure this is only done at the start of a LOW phase
//       //   }
//       // if(!lockLow && millis() - lowIn > pause){
//       //     lockLow = true;
//       //     }
//       }
//   }
