"""
This is the code to trigger the camera which is connected to
the pi to take a picture.
"""


import picamera
import time
import serial

"""
Set up the Serial communication with the board rate on the Arduino
"""
ser = serial.Serial('/dev/ttyUSB0', 9600)


"""
Instance of the camera
"""
camera = picamera.PiCamera()
"""
Flip camera display
"""
camera.vflip = True

# gives view of camera for calibration
camera.start_preview()
time.sleep(5)
camera.stop_preview()

foundFlag = True
pictureCounter = 0
imgName = "intruder"
imgExtension = ".jpg"

print("Waiting on movement data")
"""
reads arduino data forever, capturing an image if H is detected
"""
while foundFlag:
	movementData = ser.read()
	print("Test")
	print(movementData)

	if movementData == 'H':
            print("In if statement")
            foundFlag = False
            imgFile = imgName + str(pictureCounter) + imgExtension
            camera.capture(imgFile) # update to variable jpg name
            pictureCounter = pictureCounter + 1
            while movementData != 'L':
                movementData = ser.read()
                foundFlag = True
